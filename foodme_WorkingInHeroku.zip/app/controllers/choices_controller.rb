class ChoicesController < ApplicationController
  def choose
  end
end
